#include "system.h"
#include "switchers.h"
#include "indication.h"

int main()
{
    system_init();
    
    switchers_init();
    
    indication_init();
    
    while(1)
    {
        indication_update();
    }
    
    return 0;
}
