/* 
 * File:   interrupt_priorites.h
 * Author: stas
 *
 * Created on 16 ?????? 2018 ?., 16:40
 */

#ifndef INTERRUPT_PRIORITIES_H
#define	INTERRUPT_PRIORITIES_H

#define INDICATION_TIMER_INTERRUPT_PRIORITY 1


#endif	/* INTERRUPT_PRIORITES_H */

