/* 
 * File:   indication.h
 * Author: stas
 *
 * Created on 19 ?????? 2018 ?., 9:49
 */

#ifndef INDICATION_H
#define	INDICATION_H

#include "system.h"

struct ind_status_t
{
    uint8_t SUPPLY_LED_0:1;
    uint8_t PUMP_LED:1;
    uint8_t SYPPLY_LED_1:1;
    uint8_t SUPPLY_VALVE_LED:1;
    uint8_t SUPPLY_LED_2:1;
    uint8_t L_INNER_LED_8:1;
    uint8_t L_INNER_LED_7:1;
    uint8_t L_INNER_LED_6:1;
    uint8_t L_INNER_LED_5:1;
    uint8_t L_INNER_LED_4:1;
    uint8_t L_INNER_LED_3:1;
    uint8_t L_INNER_LED_2:1;
    uint8_t L_INNER_LED_1:1;
    uint8_t L_INNER_LED_0:1;
    uint8_t RELEASE_LED_0:1;
    uint8_t RELEASE_VALVE_LED:1;
    uint8_t RELEASE_LED_1:1;
    uint8_t READINNES_LED:1;
    uint8_t ACCIDENT_LED:1;
    uint8_t L_OUTER_LED_3:1;
    uint8_t L_OUTER_LED_2:1;
    uint8_t L_OUTER_LED_1:1;
    uint8_t L_OUTER_LED_0:1;
};

#define INDICATOR_COUNT 22

void indication_init();
void indication_update();

extern struct ind_status_t IND_STATUS;

#endif	/* INDICATION_H */

