#include "indication.h"
#include "pin_definitions.h"

void set_pattern(unsigned char pattern);

struct ind_status_t IND_STATUS;

void indication_init()
{
    SDI_VD_CONFIG = 0;
    CLK_VD_CONFIG = 0;
    LE_VD_CONFIG = 0;
    
    uint8_t *indPtr = &IND_STATUS;
    uint8_t i;
    for(i = 0; i < INDICATOR_COUNT; ++i) 
    {
        indPtr[i] = 0;
    }
    
    IND_STATUS.L_INNER_LED_4 = 1;
    IND_STATUS.PUMP_LED = 1;
}

void indication_update()
{
    uint8_t *indPtr = &IND_STATUS;
     
    static unsigned int currentSection = 0;
    
    interrupts_disable();
    
    set_pattern(0x00);
    set_pattern(8);
    
    interrupts_enable();
           
    if(++currentSection >= INDICATOR_COUNT) {
        currentSection = 0;
    }
}

void set_pattern(unsigned char pattern)
{
    unsigned int i;
    for(i = 0; i < 8; ++i, pattern >>= 1) {
        SDI_VD = (pattern & 1);
        CLK_VD = 1;
        CLK_VD = 0;
    }
    SDI_VD = 0;
    LE_VD = 1;
    LE_VD = 0;
}

